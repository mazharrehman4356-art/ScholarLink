# ScholarLink — School Scholarship Finder

A beginner-friendly Node.js + Express website for a school to manage student profiles and show university/scholarship matches.

## Included
- Premium responsive UI
- Unique ScholarLink-style logo built in CSS
- Student registration/login
- Secure password hashing using Node's built-in `crypto.scrypt`
- Student profile: phone, city, education, marks, field, level, budget, preferred countries
- Personalized university matching
- 30 countries and 60+ seeded universities
- Official university links
- 30 official study/scholarship source links
- School admin dashboard to add/update/delete students
- JSON database stored locally in `data/db.json`
- No student phone numbers are displayed on the public pages

## Run on Windows
1. Install Node.js LTS.
2. Open this folder in Command Prompt / PowerShell.
3. Run:
   npm install
   npm start
4. Open:
   http://localhost:3000

## Create the school admin
The first admin can be created with this endpoint. The default setup secret is `change-me-now`, but change it before putting the site online.

PowerShell:
$body = '{"name":"School Admin","email":"admin@example.com","password":"ChangeThisPassword123!"}'
Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/setup-admin -Headers @{"x-setup-secret"="change-me-now";"Content-Type"="application/json"} -Body $body

After creating the admin, log in normally from the website.

## Important before public deployment
This starter uses a local JSON file, which is good for a prototype/small school but not ideal for a large public service. For production, move the database to PostgreSQL/Supabase, add HTTPS, email verification, password reset, rate limiting, audit logs, encrypted backups, role permissions, and a privacy/consent policy.

The university and scholarship lists are a starting directory, not a promise that a scholarship is currently open. Students should always verify current eligibility, deadlines and funding on the linked official source.
