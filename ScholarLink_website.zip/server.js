const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "db.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const countries = [
  ["Germany","DE"],["United Kingdom","GB"],["United States","US"],["Canada","CA"],
  ["Australia","AU"],["Türkiye","TR"],["Malaysia","MY"],["China","CN"],
  ["Japan","JP"],["South Korea","KR"],["Finland","FI"],["Sweden","SE"],
  ["France","FR"],["Italy","IT"],["Netherlands","NL"],["Hungary","HU"],
  ["Poland","PL"],["Czech Republic","CZ"],["Ireland","IE"],["New Zealand","NZ"],
  ["Spain","ES"],["Portugal","PT"],["Austria","AT"],["Belgium","BE"],
  ["Denmark","DK"],["Norway","NO"],["Switzerland","CH"],["UAE","AE"],
  ["Saudi Arabia","SA"],["Qatar","QA"]
];

const universities = [
  ["Technical University of Munich","Germany","Computer Science, Engineering, AI","Bachelor, Master","https://www.tum.de/"],
  ["RWTH Aachen University","Germany","Engineering, Computer Science","Bachelor, Master","https://www.rwth-aachen.de/"],
  ["University of Oxford","United Kingdom","Computer Science, Business, Sciences","Bachelor, Master, Doctorate","https://www.ox.ac.uk/"],
  ["Imperial College London","United Kingdom","Engineering, Computing, Sciences","Bachelor, Master, Doctorate","https://www.imperial.ac.uk/"],
  ["MIT","United States","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://www.mit.edu/"],
  ["Stanford University","United States","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://www.stanford.edu/"],
  ["University of Toronto","Canada","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://www.utoronto.ca/"],
  ["University of British Columbia","Canada","Computer Science, Engineering, Sciences","Bachelor, Master","https://www.ubc.ca/"],
  ["University of Melbourne","Australia","IT, Engineering, Business, Sciences","Bachelor, Master, Doctorate","https://www.unimelb.edu.au/"],
  ["Australian National University","Australia","Computing, Engineering, Sciences","Bachelor, Master, Doctorate","https://www.anu.edu.au/"],
  ["Middle East Technical University","Türkiye","Engineering, Computer Science","Bachelor, Master","https://www.metu.edu.tr/"],
  ["Istanbul Technical University","Türkiye","Engineering, Architecture, Computing","Bachelor, Master","https://www.itu.edu.tr/"],
  ["Universiti Malaya","Malaysia","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://www.um.edu.my/"],
  ["Universiti Teknologi Malaysia","Malaysia","Engineering, Computing, Technology","Bachelor, Master, Doctorate","https://www.utm.my/"],
  ["Tsinghua University","China","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://www.tsinghua.edu.cn/en/"],
  ["Peking University","China","Computer Science, Sciences, Business","Bachelor, Master, Doctorate","https://english.pku.edu.cn/"],
  ["University of Tokyo","Japan","Engineering, Computer Science, Sciences","Bachelor, Master, Doctorate","https://www.u-tokyo.ac.jp/en/"],
  ["Kyoto University","Japan","Engineering, Sciences, Informatics","Bachelor, Master, Doctorate","https://www.kyoto-u.ac.jp/en"],
  ["KAIST","South Korea","AI, Computer Science, Engineering","Bachelor, Master, Doctorate","https://www.kaist.ac.kr/en/"],
  ["Seoul National University","South Korea","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://en.snu.ac.kr/"],
  ["Aalto University","Finland","Computer Science, Technology, Business","Bachelor, Master","https://www.aalto.fi/en"],
  ["University of Helsinki","Finland","Computer Science, Sciences, Education","Bachelor, Master, Doctorate","https://www.helsinki.fi/en"],
  ["KTH Royal Institute of Technology","Sweden","Computer Science, Engineering, Technology","Bachelor, Master, Doctorate","https://www.kth.se/en"],
  ["Lund University","Sweden","Engineering, Computer Science, Sciences","Bachelor, Master, Doctorate","https://www.lunduniversity.lu.se/"],
  ["Sorbonne University","France","Computer Science, Sciences, Engineering","Bachelor, Master, Doctorate","https://www.sorbonne-universite.fr/en"],
  ["Université Paris-Saclay","France","Computer Science, Sciences, Engineering","Bachelor, Master, Doctorate","https://www.universite-paris-saclay.fr/en"],
  ["Politecnico di Milano","Italy","Engineering, Architecture, Design","Bachelor, Master, Doctorate","https://www.polimi.it/en"],
  ["University of Bologna","Italy","Computer Science, Business, Sciences","Bachelor, Master, Doctorate","https://www.unibo.it/en"],
  ["Delft University of Technology","Netherlands","Engineering, Computer Science, Technology","Bachelor, Master","https://www.tudelft.nl/en"],
  ["University of Amsterdam","Netherlands","Computer Science, Business, Sciences","Bachelor, Master, Doctorate","https://www.uva.nl/en"],
  ["Trinity College Dublin","Ireland","Computer Science, Business, Sciences","Bachelor, Master, Doctorate","https://www.tcd.ie/"],
  ["University College Dublin","Ireland","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://www.ucd.ie/"],
  ["University of Auckland","New Zealand","Engineering, Computer Science, Business","Bachelor, Master, Doctorate","https://www.auckland.ac.nz/en.html"],
  ["University of Otago","New Zealand","Sciences, Health, Business","Bachelor, Master, Doctorate","https://www.otago.ac.nz/"],
  ["ETH Zurich","Switzerland","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://ethz.ch/en.html"],
  ["EPFL","Switzerland","Computer Science, Engineering, Technology","Bachelor, Master, Doctorate","https://www.epfl.ch/en/"],
  ["University of Vienna","Austria","Computer Science, Sciences, Business","Bachelor, Master, Doctorate","https://www.univie.ac.at/en/"],
  ["TU Wien","Austria","Computer Science, Engineering, Technology","Bachelor, Master","https://www.tuwien.at/en/"],
  ["KU Leuven","Belgium","Engineering, Computer Science, Sciences","Bachelor, Master, Doctorate","https://www.kuleuven.be/english/"],
  ["Ghent University","Belgium","Engineering, Sciences, Computer Science","Bachelor, Master, Doctorate","https://www.ugent.be/en"],
  ["University of Copenhagen","Denmark","Computer Science, Sciences, Health","Bachelor, Master, Doctorate","https://www.ku.dk/english/"],
  ["Technical University of Denmark","Denmark","Engineering, Technology, Computer Science","Bachelor, Master, Doctorate","https://www.dtu.dk/english"],
  ["University of Oslo","Norway","Computer Science, Sciences, Social Sciences","Bachelor, Master, Doctorate","https://www.uio.no/english/"],
  ["Norwegian University of Science and Technology","Norway","Engineering, Computer Science, Technology","Bachelor, Master, Doctorate","https://www.ntnu.edu/"],
  ["University of Warsaw","Poland","Computer Science, Sciences, Business","Bachelor, Master, Doctorate","https://en.uw.edu.pl/"],
  ["Warsaw University of Technology","Poland","Engineering, Computer Science, Technology","Bachelor, Master","https://www.pw.edu.pl/engpw"],
  ["ELTE Eötvös Loránd University","Hungary","Computer Science, Sciences, Humanities","Bachelor, Master, Doctorate","https://www.elte.hu/en"],
  ["Budapest University of Technology","Hungary","Engineering, Computer Science, Technology","Bachelor, Master","https://www.bme.hu/?language=en"],
  ["Charles University","Czech Republic","Computer Science, Sciences, Humanities","Bachelor, Master, Doctorate","https://cuni.cz/UKEN-1.html"],
  ["Czech Technical University in Prague","Czech Republic","Engineering, Computer Science, Technology","Bachelor, Master","https://www.cvut.cz/en"],
  ["University of Barcelona","Spain","Computer Science, Sciences, Business","Bachelor, Master, Doctorate","https://www.ub.edu/web/portal/en/"],
  ["Autonomous University of Madrid","Spain","Computer Science, Sciences, Business","Bachelor, Master, Doctorate","https://www.uam.es/uam/en"],
  ["University of Lisbon","Portugal","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://www.ulisboa.pt/en"],
  ["University of Porto","Portugal","Engineering, Computer Science, Sciences","Bachelor, Master, Doctorate","https://www.up.pt/portal/en/"],
  ["King Abdullah University of Science and Technology","Saudi Arabia","AI, Computer Science, Engineering","Master, Doctorate","https://www.kaust.edu.sa/"],
  ["King Saud University","Saudi Arabia","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://ksu.edu.sa/en"],
  ["Khalifa University","UAE","Engineering, Computer Science, AI","Bachelor, Master, Doctorate","https://www.ku.ac.ae/"],
  ["United Arab Emirates University","UAE","Computer Science, Engineering, Sciences","Bachelor, Master, Doctorate","https://www.uaeu.ac.ae/en/"],
  ["Hamad Bin Khalifa University","Qatar","Computer Science, Engineering, Public Policy","Master, Doctorate","https://www.hbku.edu.qa/en"],
  ["Qatar University","Qatar","Computer Science, Engineering, Business","Bachelor, Master, Doctorate","https://www.qu.edu.qa/"]
].map((u,i)=>({id:i+1,name:u[0],country:u[1],fields:u[2].split(", "),levels:u[3].split(", "),officialUrl:u[4]}));

const scholarshipSources = [
  ["Germany","DAAD","https://www.daad.de/en/"],["United Kingdom","British Council","https://study-uk.britishcouncil.org/"],
  ["United States","EducationUSA","https://educationusa.state.gov/"],["Canada","EduCanada","https://www.educanada.ca/"],
  ["Australia","Australia Awards","https://www.dfat.gov.au/people-to-people/australia-awards"],["Türkiye","Türkiye Scholarships","https://www.turkiyeburslari.gov.tr/"],
  ["Malaysia","Education Malaysia","https://educationmalaysia.gov.my/"],["China","China Scholarship Council","https://www.csc.edu.cn/"],
  ["Japan","Study in Japan","https://www.studyinjapan.go.jp/en/"],["South Korea","Study in Korea","https://www.studyinkorea.go.kr/"],
  ["Finland","Study in Finland","https://www.studyinfinland.fi/"],["Sweden","Study in Sweden","https://studyinsweden.se/"],
  ["France","Campus France","https://www.campusfrance.org/en"],["Italy","Study in Italy","https://studyinitaly.esteri.it/"],
  ["Netherlands","Study in NL","https://www.studyinnl.org/"],["Hungary","Stipendium Hungaricum","https://stipendiumhungaricum.hu/"],
  ["Poland","Study in Poland","https://study.gov.pl/"],["Czech Republic","Study in Czechia","https://www.studyin.cz/"],
  ["Ireland","Education in Ireland","https://www.educationinireland.com/"],["New Zealand","Education New Zealand","https://www.studywithnewzealand.govt.nz/"],
  ["Spain","Study in Spain","https://www.spain.info/en/"],["Portugal","Study & Research in Portugal","https://www.study-research.pt/"],
  ["Austria","Study in Austria","https://studyinaustria.at/en/"],["Belgium","Study in Belgium","https://www.studyinbelgium.be/"],
  ["Denmark","Study in Denmark","https://studyindenmark.dk/"],["Norway","Study in Norway","https://studyinnorway.no/"],
  ["Switzerland","Study in Switzerland","https://www.swissuniversities.ch/en/"],["UAE","UAE Ministry of Education","https://www.moe.gov.ae/en/Pages/default.aspx"],
  ["Saudi Arabia","Study in Saudi","https://studyinsaudi.moe.gov.sa/"],["Qatar","Study in Qatar","https://www.edu.gov.qa/en/"]
].map((x,i)=>({id:i+1,country:x[0],name:x[1],url:x[2]}));

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const key = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${key}`;
}
function verifyPassword(password, stored) {
  const [salt,key] = stored.split(":");
  const test = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(key,"hex"), Buffer.from(test,"hex"));
}
function loadDB() {
  if (!fs.existsSync(DATA_FILE)) {
    const db = {users:[],students:[],sessions:[],universities,scholarshipSources,countries};
    fs.writeFileSync(DATA_FILE, JSON.stringify(db,null,2));
    return db;
  }
  return JSON.parse(fs.readFileSync(DATA_FILE,"utf8"));
}
function saveDB(db){ fs.writeFileSync(DATA_FILE, JSON.stringify(db,null,2)); }
let db = loadDB();
if (!db.universities?.length) { db.universities=universities; db.scholarshipSources=scholarshipSources; db.countries=countries; saveDB(db); }

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next) {
  const token = req.headers.authorization?.replace("Bearer ","");
  const session = db.sessions.find(s=>s.token===token && s.expiresAt>Date.now());
  if (!session) return res.status(401).json({error:"Please log in."});
  req.user = db.users.find(u=>u.id===session.userId);
  if (!req.user) return res.status(401).json({error:"Invalid session."});
  next();
}
function admin(req,res,next){ if(req.user.role!=="admin") return res.status(403).json({error:"Admin access required."}); next(); }

app.get("/api/health",(req,res)=>res.json({ok:true}));
app.get("/api/countries",(req,res)=>res.json(db.countries));
app.get("/api/scholarship-sources",(req,res)=>res.json(db.scholarshipSources));
app.get("/api/universities",(req,res)=>{
  const q=(req.query.q||"").toLowerCase(), country=req.query.country||"", field=req.query.field||"", level=req.query.level||"";
  let items=db.universities.filter(u=>
    (!q || `${u.name} ${u.country} ${u.fields.join(" ")}`.toLowerCase().includes(q)) &&
    (!country || u.country===country) &&
    (!field || u.fields.some(f=>f.toLowerCase().includes(field.toLowerCase()))) &&
    (!level || u.levels.includes(level))
  );
  res.json(items);
});
app.post("/api/register", (req,res)=>{
  const {name,email,password} = req.body||{};
  if(!name||!email||!password||password.length<8) return res.status(400).json({error:"Name, email and a password of at least 8 characters are required."});
  if(db.users.some(u=>u.email.toLowerCase()===email.toLowerCase())) return res.status(409).json({error:"Email is already registered."});
  const id = crypto.randomUUID();
  db.users.push({id,name,email:email.toLowerCase(),passwordHash:hashPassword(password),role:"student",createdAt:new Date().toISOString()});
  saveDB(db);
  res.json({ok:true});
});
app.post("/api/login",(req,res)=>{
  const {email,password}=req.body||{};
  const user=db.users.find(u=>u.email.toLowerCase()===(email||"").toLowerCase());
  if(!user || !verifyPassword(password||"",user.passwordHash)) return res.status(401).json({error:"Invalid email or password."});
  const token=crypto.randomBytes(32).toString("hex");
  db.sessions=db.sessions.filter(s=>s.expiresAt>Date.now());
  db.sessions.push({token,userId:user.id,expiresAt:Date.now()+1000*60*60*24*7});
  saveDB(db);
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});
app.get("/api/me",auth,(req,res)=>res.json({user:{id:req.user.id,name:req.user.name,email:req.user.email,role:req.user.role}}));

app.get("/api/profile",auth,(req,res)=>{
  const p=db.students.find(s=>s.userId===req.user.id);
  res.json(p||null);
});
app.post("/api/profile",auth,(req,res)=>{
  const allowed=["fullName","phone","city","education","marks","field","preferredCountries","budget","studyLevel"];
  const incoming=req.body||{};
  let p=db.students.find(s=>s.userId===req.user.id);
  if(!p){p={id:crypto.randomUUID(),userId:req.user.id,createdAt:new Date().toISOString()}; db.students.push(p);}
  allowed.forEach(k=>{if(incoming[k]!==undefined)p[k]=incoming[k]});
  p.updatedAt=new Date().toISOString();
  saveDB(db); res.json(p);
});

app.get("/api/matches",auth,(req,res)=>{
  const p=db.students.find(s=>s.userId===req.user.id);
  if(!p) return res.json({universities:[],sources:[],message:"Complete your profile first."});
  const countriesWanted = Array.isArray(p.preferredCountries) ? p.preferredCountries : [];
  const field=(p.field||"").toLowerCase(), level=p.studyLevel||p.education||"";
  const marks=parseFloat(p.marks)||0;
  const scored=db.universities.map(u=>{
    let score=0;
    if(countriesWanted.includes(u.country)) score+=35;
    if(field && u.fields.some(f=>f.toLowerCase().includes(field)||field.includes(f.toLowerCase()))) score+=35;
    if(level && u.levels.some(l=>l.toLowerCase().includes(level.toLowerCase())||level.toLowerCase().includes(l.toLowerCase()))) score+=20;
    if(marks>=80) score+=10;
    return {...u,matchScore:Math.min(score,100)};
  }).filter(u=>u.matchScore>0).sort((a,b)=>b.matchScore-a.matchScore).slice(0,30);
  const sources=db.scholarshipSources.filter(s=>countriesWanted.length===0||countriesWanted.includes(s.country));
  res.json({universities:scored,sources});
});

// Admin: school can add/manage students.
app.post("/api/admin/students",auth,admin,(req,res)=>{
  const x=req.body||{};
  if(!x.fullName||!x.phone||!x.email) return res.status(400).json({error:"Full name, phone and email are required."});
  let user=db.users.find(u=>u.email===x.email.toLowerCase());
  if(!user){
    const temp=crypto.randomBytes(6).toString("base64url");
    user={id:crypto.randomUUID(),name:x.fullName,email:x.email.toLowerCase(),passwordHash:hashPassword(temp),role:"student",createdAt:new Date().toISOString()};
    db.users.push(user);
  }
  let p=db.students.find(s=>s.userId===user.id);
  if(!p){p={id:crypto.randomUUID(),userId:user.id,createdAt:new Date().toISOString()};db.students.push(p);}
  Object.assign(p,x,{userId:user.id,updatedAt:new Date().toISOString()});
  saveDB(db); res.json(p);
});
app.get("/api/admin/students",auth,admin,(req,res)=>{
  res.json(db.students.map(s=>({...s,user:db.users.find(u=>u.id===s.userId)?{name:db.users.find(u=>u.id===s.userId).name,email:db.users.find(u=>u.id===s.userId).email}:null})));
});
app.delete("/api/admin/students/:id",auth,admin,(req,res)=>{
  const s=db.students.find(x=>x.id===req.params.id); if(!s)return res.status(404).json({error:"Student not found."});
  db.students=db.students.filter(x=>x.id!==s.id); saveDB(db); res.json({ok:true});
});

app.post("/api/setup-admin",(req,res)=>{
  const secret=req.headers["x-setup-secret"];
  if(secret!==(process.env.ADMIN_SETUP_SECRET||"change-me-now")) return res.status(403).json({error:"Wrong setup secret."});
  if(db.users.some(u=>u.role==="admin")) return res.status(409).json({error:"Admin already exists."});
  const {name,email,password}=req.body||{};
  if(!name||!email||!password||password.length<8)return res.status(400).json({error:"Name, email and password (8+ chars) required."});
  const user={id:crypto.randomUUID(),name,email:email.toLowerCase(),passwordHash:hashPassword(password),role:"admin",createdAt:new Date().toISOString()};
  db.users.push(user); saveDB(db); res.json({ok:true,message:"Admin created. Remove/change the setup secret before public deployment."});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`ScholarLink running on http://localhost:${PORT}`));
